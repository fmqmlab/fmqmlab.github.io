@author: Fahad Mahmood Group
Last updated: 12 Jul 2023

Thank you for installing PyDPE. This python package plots a raw image file from our ARTOF detector, and shows the regions of the Brillouin zone where double photon emission might be observed. 

Users are expected to interact with the package through a gui written using ipywidgets. As such, PyDPE can be run only on Jupiter Notebooks (or other IPython Kernels).

DEPENDENCIES
############

Please make sure the following dependencies are installed locally before attempting to run PyDPE:

- Python (< 3.11) -- https://www.python.org
- Jupyter Notebook -- https://matplotlib.org/stable/users/installing/index.html
- matplotlib -- https://matplotlib.org/stable/users/installing/index.html
- numpy -- https://numpy.org/install/
- xarray -- https://docs.xarray.dev/en/stable/getting-started-guide/installing.html
- ipywidgets -- https://ipywidgets.readthedocs.io/en/stable/user_install.html
- scikit-image -- https://scikit-image.org/docs/stable/user_guide/install.html

RUNNING PYDPE
#############

The PyDPE gui is contained in the "dpe_gui_mod()" method inside the "gui.py" file. Calling this method from a Jupyter Notebook launches the gui. This can be done as follows:

- Open Jupyter Notebook and change the working directory to the one where gui.py is located
- Start a new ipynotebook
- import guido into the cell
- run "dpe_gui_mod()" inside the cell

