from . import angle_transformation

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as img

import skimage.color

import xarray as xr

import ipywidgets as widgets
from enum import IntEnum
        
def dpe_gui_mod():#Controls the GUI for the DPE configuration. Interacting with the widgets calls the dpe function
    image_file_box= widgets.Text(value='', placeholder='Type something',description='Filename', continuous_update=False)
    extent_x_slider = widgets.FloatRangeSlider(value=[-1, 1], min=-10, max=10, step=0.01, description='extent_x', continuous_update=False,readout=True,readout_format='.2f')
    extent_y_slider = widgets.FloatRangeSlider(value=[-1, 1], min=-10, max=10, step=0.01, description='extent_y', continuous_update=False,readout=True,readout_format='.2f')
    theta_s_slider = widgets.FloatSlider(value = 90, min=0, max=180, step=0.2, description=r'$\theta_s$', continuous_update=False)
    phi_s_slider = widgets.FloatSlider(value = 45, min=-15, max=105, step=1, description=r'$\phi_s$', continuous_update=False)
    rotation_s_slider = widgets.FloatSlider(value = 0, min=0, max=360, step=2, description='rotation_s', continuous_update=False)
    #This is where the mod function differs from the original: the inputs are the photon energy and the work function.
    #It is assumed that only electrons at the fermi surface are probed.
    hv_slider = widgets.FloatSlider(value=22.8, min=0, max=40, step=0.01, description=r'$hv$', continuous_update=False)
    wf_slider = widgets.FloatSlider(value=4.5, min=3, max=7, step=0.01, description=r'$wf$', continuous_update=False)
    #
    FOV_slider = widgets.FloatSlider(value=15, min=5, max=20, step = 0.1, description='FOV', continuous_update=False)
    interactive_plot = widgets.interact(dpe_mod, image_file=image_file_box, extent_x=extent_x_slider, extent_y=extent_y_slider, theta_s=theta_s_slider, phi_s=phi_s_slider, rotation_s=rotation_s_slider, hv=hv_slider,wf=wf_slider, FOV=FOV_slider)
    return interactive_plot


def dpe_mod(image_file, extent_x, extent_y, theta_s, phi_s, rotation_s,hv,wf, FOV ):
    E_k1 = (hv-2*wf)/2
    E_k2 = (hv-2*wf)/2
    
    theta_s = np.radians(theta_s)
    phi_s = np.radians(phi_s)
    rotation_s = np.radians(rotation_s)
    FOV = np.radians(FOV)

    _phi = np.linspace(0, 2 * np.pi, 361)
    _theta = FOV * np.ones_like(_phi)
    kp1x, kp1y = angle_transformation.analyser_angle_to_k(theta_s, phi_s, rotation_s, E_k1, _theta, _phi, angle_transformation.Det.DETA)
    kp2x, kp2y = angle_transformation.analyser_angle_to_k(theta_s, phi_s, rotation_s, E_k2, _theta, _phi, angle_transformation.Det.DETB)
    kc1x, kc1y = angle_transformation.analyser_angle_to_k(theta_s, phi_s, rotation_s, E_k1, FOV, np.radians(0), angle_transformation.Det.DETA )
    kc2x, kc2y = angle_transformation.analyser_angle_to_k(theta_s, phi_s, rotation_s, E_k2, FOV, np.radians(0), angle_transformation.Det.DETB )

    extent_list = [extent_y[0], extent_y[1], extent_x[0], extent_x[1], ] ##ky min max kx min max

    
    if image_file == "":
        return
    if image_file != getattr(dpe_mod, "loaded_filename", None) or extent_list != getattr(dpe_mod, 'loaded_extent', None) :
        dpe_mod.loaded_filename = image_file
        dpe_mod.loaded_extent = extent_list
        image_rgb = img.imread(image_file)
        data = skimage.color.rgb2gray(skimage.color.rgba2rgb(image_rgb))
        dpe_mod.loaded_data = xr.DataArray(data.transpose(), dims=['kx', 'ky'], coords={'ky':np.linspace(extent_list[1], extent_list[0], data.shape[0]),
                                                  'kx':np.linspace(extent_list[2], extent_list[3], data.shape[1])})

   
    
    transform1 = angle_transformation.backward_transformation(dpe_mod.loaded_data, 
                                                                   {'theta_s':theta_s, 'phi_s':phi_s, 'rotation_s':rotation_s}, 
                                                                   E_k1, angle_transformation.Det.DETA, FOV, grid_dimensions=[76, 361])

    transform2 = angle_transformation.backward_transformation(dpe_mod.loaded_data, 
                                                                   {'theta_s':theta_s, 'phi_s':phi_s, 'rotation_s':rotation_s}, 
                                                                   E_k2, angle_transformation.Det.DETB, FOV, grid_dimensions=[76, 361])


    plt.figure(figsize=[25, 7])
    ax1 = plt.subplot(131)
    dpe.loaded_data.plot(ax=ax1, x='kx', y='ky')
    ax1.plot(kp1x, kp1y, c='black')
    ax1.plot(kp2x, kp2y, c='black')
    ax1.scatter(kc1x, kc1y, c='black', s=50)
    ax1.scatter(kc2x, kc2y, c='black', s=50)
    ax1.axis('equal')

    ax2= plt.subplot(132, projection='polar')
    ax2.set_theta_offset(np.pi/2)
    ax2.pcolormesh(transform1.coords['phi'].values, np.degrees(transform1.coords['theta'].values), transform1.values, shading='auto')
    
    ax3= plt.subplot(133, projection='polar')
    ax3.set_theta_offset(np.pi/2)
    ax3.pcolormesh(transform2.coords['phi'].values, np.degrees(transform2.coords['theta'].values), transform2.values, shading='auto')
    plt.show()

